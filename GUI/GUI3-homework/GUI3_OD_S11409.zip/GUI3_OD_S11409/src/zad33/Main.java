/**
 *
 *  @author Orzeszek Dorota S11409
 *
 */
package zad33;


public class Main {
	
	public static void main(String ... args) {
		
		 /* udało mi się tylko doprowadzić do wyświetlenia każdego obrazka w nowym oknie z odpowiednim opóźnieniem :(
		  * --> metoda main w pliku ImagePaneTest.java
		  */
	  
  
  }
}