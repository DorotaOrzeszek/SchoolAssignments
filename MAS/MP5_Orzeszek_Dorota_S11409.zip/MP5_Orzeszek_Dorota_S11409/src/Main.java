/**
 * 
 * @author Dorota Orzeszek
 * Mini-projekt 5: Model relacyjny
 *
 */


import java.util.Date;
import java.util.List;

import org.hibernate.Session;

public class Main {
	public static void main(String[] args) {

    	/*
    	 * Mapowanie klas
    	 */
    	
    	System.out.println("========== MR - KLASY ==========");
    	System.out.println("Do bazy dodawane są 3 rekordy przedstawiające obiekty klasy Student");
    			
    	Main m = new Main();
        m.createAndStoreStudent("Jan Kowalski", new Date(1980, 5, 30));
        m.createAndStoreStudent("Ewa Nowak", new Date(1985, 4, 1));
        m.createAndStoreStudent("Anna Kwiatkowska", new Date(1990, 1, 2));
        
        /*
         * Wyświetlanie zawartości utworzonej tabeli
         */
        @SuppressWarnings("rawtypes")
		List studenci = m.pokazStudentow();
        
        for (int i = 0; i < studenci.size(); i++) {
        Student theStudent = (Student) studenci.get(i);
         
        System.out.println("Student: " + theStudent.getImieNazwisko() + " ur. "
                    + theStudent.getDataUrodzenia());
        }
        
        /* Mapowanie asocjacji
         * Klasy Student i Przedmiot zostały powiązane asocjacją
         * (patrz: addStudentToPrzedmiot()
         */        
        
    	System.out.println("========== MR - ASOCJACJE ==========");
    	System.out.println("Powiązano obiekt klasy Student z obiektem Przedmiot");
    			
        Long studentId = m.createAndStoreStudent("Adam Kowalski", new Date(1980, 5, 31));
        Long przedmiotId = m.createAndStorePrzedmiot("Analiza matematyczna");

        m.addStudentToPrzedmiot(studentId, przedmiotId);
        System.out.println("Dodano studenta " + studentId + " do przedmiotu " + przedmiotId);
        
        HibernateUtil.getSessionFactory().close();
    }
 
    private Long createAndStoreStudent(String imieNazwisko, Date dataUrodzenia) {
 
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
 
        session.beginTransaction();
 
        Student theStudent = new Student();
        theStudent.setImieNazwisko(imieNazwisko);
        theStudent.setDataUrodzenia(dataUrodzenia);
        Long studentId = theStudent.getId();
        
        session.save(theStudent);
 
        session.getTransaction().commit();
        
        return studentId;
    }
    
    private Long createAndStorePrzedmiot(String nazwa) {
    	 
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
 
        session.beginTransaction();
 
        Przedmiot thePrzedmiot = new Przedmiot();
        thePrzedmiot.setNazwa(nazwa);
        Long przedmiotId = thePrzedmiot.getId();
        
        session.save(thePrzedmiot);
 
        session.getTransaction().commit();
        
        return przedmiotId;
    }
    
    private List<Student> pokazStudentow() {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        List result = session.createQuery("from Students").list();
        session.getTransaction().commit();
     
        return result;
    }
    
    private void addStudentToPrzedmiot(Long studentId, Long przedmiotId) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
     
        Student aStudent = (Student) session.load(Student.class, studentId);
        Przedmiot anPrzedmiot = (Przedmiot) session.load(Przedmiot.class, przedmiotId);
        aStudent.getPrzedmioty().add(anPrzedmiot);
        session.getTransaction().commit();
    }
}