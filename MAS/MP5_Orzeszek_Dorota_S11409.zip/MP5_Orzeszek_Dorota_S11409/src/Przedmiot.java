public class Przedmiot {

    private Long id;
    private String nazwa;
    
    public Przedmiot() {}
 
    public Long getId() {
        return id;
    }
    private void setId(Long id) {
        this.id = id;
    }
    public String getNazwa() {
        return nazwa;
    }
    public void setNazwa(String name) {
        this.nazwa = name;
    }
    
}
