import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Student {
    private Long id;
    private String imieNazwisko;
    private Date dataUrodzenia;
    private Set przedmioty = new HashSet();
    
    public Student() {}
 
    public Long getId() {
        return id;
    }
    private void setId(Long id) {
        this.id = id;
    }
    public Date getDataUrodzenia() {
        return dataUrodzenia;
    }
    public void setDataUrodzenia(Date date) {
        this.dataUrodzenia = date;
    }
    public String getImieNazwisko() {
        return imieNazwisko;
    }
    public void setImieNazwisko(String name) {
        this.imieNazwisko = name;
    }
    public Set getPrzedmioty() {
        return przedmioty;
    }
    public void setPrzedmioty(Set przedmioty) {
        this.przedmioty = przedmioty;
    }
}