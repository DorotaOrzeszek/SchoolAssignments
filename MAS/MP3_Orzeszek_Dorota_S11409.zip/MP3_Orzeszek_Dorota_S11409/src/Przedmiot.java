import java.util.EnumSet;

enum PrzedmiotRodzaj {Przedmiot, Wyklad, Cwiczenia};
 
public class Przedmiot {
	
    String kod;
    String nazwa;
 
    boolean egzamin;
    boolean zaliczenie;
    
    EnumSet<PrzedmiotRodzaj> rodzajPrzedmiotu =  EnumSet.<PrzedmiotRodzaj>of(PrzedmiotRodzaj.Przedmiot);

    public Przedmiot(String kod, String nazwa, boolean wyklad, boolean cwiczenia) {
    	this.kod = kod;
    	this.nazwa = nazwa;
    	if (wyklad == true && cwiczenia == true) {
    		rodzajPrzedmiotu =  EnumSet.<PrzedmiotRodzaj>of(PrzedmiotRodzaj.Wyklad, PrzedmiotRodzaj.Cwiczenia);
    		this.egzamin = true;
    		this.zaliczenie = true;
    	} else if (wyklad == true) {
    		rodzajPrzedmiotu =  EnumSet.<PrzedmiotRodzaj>of(PrzedmiotRodzaj.Wyklad);
    		this.egzamin = true;
    	} else if (cwiczenia == true) {
    		rodzajPrzedmiotu =  EnumSet.<PrzedmiotRodzaj>of(PrzedmiotRodzaj.Cwiczenia);
    		this.zaliczenie = true;
    	}
    }
}