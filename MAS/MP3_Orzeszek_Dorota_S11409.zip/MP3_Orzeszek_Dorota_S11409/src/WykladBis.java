
public interface WykladBis {
	
	boolean egzamin = true;
	
	void przeprowadzEgzamin();

}
