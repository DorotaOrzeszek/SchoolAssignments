
/**
 * 
 * @author Dorota Orzeszek
 * Mini-projekt 3: Dziedziczenie
 *
 */

public class Main {

	public static void main(String[] args) throws Exception {
		
		/**
		 * Klasa abstrakcyjna
		 * 
		 * Klasa abstrakcyjna to klasa, która nie może mieć bezpośrednich wystąpień.
		 */
		
		System.out.println("======= KLASA ABSTRAKCYJNA =======");
		System.out.println("Klasą abstrakcyjną jest klasa Osoba. Będzie ona wykorzystywania do dziedziczenia przez inne klasy");
		
		System.out.println();
		
		/**
		 * Disjoint
		 * 
		 * Dziedziczenie rozłączne to najprostsza forma dziedziczenia - pozwala na utworzenie nowej podklasy wykorzystując
		 * kod z istniejącej klasy (nadklasy).
		 */
		
		System.out.println("======= DISJOINT =======");
		System.out.println("Klasy Student i PracownikDziekanatu dziedziczą po klasie abstrakcyjnej Osoba.");
		Student s1 = new Student(10001, "Jan", "Kowalski", "j.kowalski@email.com", 250);
		PracownikDziekanatu pd1 = new PracownikDziekanatu(1005, "Ewa", "Nowak", "e.nowak@uczelnia.pl", 2100);
		
		System.out.println();
		
		/**
		 * Polimorficzne wołanie metody
		 * 
		 * Polimorfizm pozwala na wołanie różnych implementacji metody o tej samej sygnaturze dla różnych typów obiektów.
		 */
		
		System.out.println("======= POLIMORFICZNE WOŁANIE METODY =======");
		double rocznePrzychodyStudenta = s1.obliczRocznePrzychody();
		double rocznePrzychodyPracownikaDziekanatu = pd1.obliczRocznePrzychody();
		System.out.println("Roczne przychody studenta: " + rocznePrzychodyStudenta);
		System.out.println("Roczne przychody pracownika dziekanatu: " + rocznePrzychodyPracownikaDziekanatu);
		
		System.out.println();
		
		/**
		 * Overlapping
		 * 
		 * Overlapping to rodzaj dziedziczenia, który pozwala podklasie dziedziczyć cechy po wielu nadklasach.
		 * Zasadniczo nie występuje w Javie - trzeba go "sztucznie" zaimplementować, np. poprzez "spłaszczenie".
		 */
		
		System.out.println("======= OVERLAPPING =======");
		System.out.println("Klasa Przedmiot powinna być nadklasą dla klas Wykład i Cwiczenia.");
		System.out.println("Obie podklasy mają atrybuty kod i nazwa, ale różnią się formą zaliczenia (egzamin, zaliczenie)");
		
		Przedmiot p1 = new Przedmiot("MAS", "Modelowanie i Analiza Systemów", false, true);
		Przedmiot p2 = new Przedmiot("ZPR", "Zarządzanie projektem inforamtycznym", true, false);
		Przedmiot p3 = new Przedmiot("AM", "Analiza matematyczna", true, true);
		
		System.out.println();
		
		/**
		 * Wielodziedziczenie
		 * 
		 * Wielodziedziczenie, podobnie jak overlapping to rodzaj dziedziczenia, który pozwala podklasie dziedziczyć cechy po wielu nadklasach.
		 * Występuje w C++, ale w Javie osiąga się je poprzez stosowanie interfejsów.
		 * 
		 * Przedmioty, Wykłady i Cwiczenia można "bardziej elegancko" niż overlappingiem z kompozycją zaimplementować przy użyciu interfejsów.
		 */
		
		System.out.println("======= WIELODZIEDZICZENIE =======");
		System.out.println("Klasa PrzedmiotBis to wykład z ćwiczeniami, więc implementuje interfejsy WykładBis i CwiczeniaBis.");
				
		PrzedmiotBis pbis = new PrzedmiotBis("AM", "Analiza matematyczna");
		pbis.wystawZaliczenia();
		pbis.przeprowadzEgzamin();
		
		System.out.println();

	}

}
