
public abstract class Osoba {
	
	String imie;
	String nazwisko;
	String email;
	
	abstract double obliczRocznePrzychody();

}
