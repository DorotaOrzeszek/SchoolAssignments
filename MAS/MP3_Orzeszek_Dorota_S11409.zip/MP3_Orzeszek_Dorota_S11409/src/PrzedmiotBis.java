
public class PrzedmiotBis implements WykladBis, CwiczeniaBis {

	String kod;
	String nazwa;
	
	public PrzedmiotBis(String kod, String nazwa) {
		this.kod = kod;
		this.nazwa = nazwa;
	}
	
	public void przeprowadzEgzamin() {
		System.out.println("Egzamin trwa... studenci ściągają a i tak dostaną tróje :P");
	}
	
	public void wystawZaliczenia() {
		System.out.println("Wszyscy dostali piątki! :)");
	}
	
}
