
public interface CwiczeniaBis {
	
	boolean zaliczenie = true;
	
	public void wystawZaliczenia();

}
