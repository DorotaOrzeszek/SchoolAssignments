
public class PracownikDziekanatu extends Osoba {
	
	int nr_pracownika;
	double pensja;
	
	public PracownikDziekanatu(int nr, String imie, String nazwisko, String email, double p) {
		super();
		this.nr_pracownika = nr;
		this.imie = imie;
		this.nazwisko = nazwisko;
		this.email = email;
		this.pensja = p;
	}
	
	public double obliczRocznePrzychody() {
		return 12*this.pensja;
	}

}
