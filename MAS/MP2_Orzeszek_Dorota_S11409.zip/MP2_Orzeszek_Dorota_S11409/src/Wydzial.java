import java.util.ArrayList;
import java.util.TreeMap;
import java.util.Vector;


public class Wydzial {
	
	int id;
	String nazwa;
	Adres adres;
	ArrayList<Student> studenci = new ArrayList<Student>();

    TreeMap<Integer, Student> studentKwalif = new TreeMap<Integer, Student>();
    
    public void dodajStudentKwalif(Student nowyStudent) {
        if(!studentKwalif.containsKey(nowyStudent.nr_indeksu)) {
        	studentKwalif.put(nowyStudent.nr_indeksu, nowyStudent);
            nowyStudent.dodajWydzial(this);
        }
    }
 
    public Student znajdzStudentKwalif(int nr_indeksu) throws Exception {
        if(!studentKwalif.containsKey(nr_indeksu)) {
            throw new Exception("Nie odnaleziono studenta o nr_indeksu: " + nr_indeksu);
        }
        return studentKwalif.get(nr_indeksu);
    }
	
    Vector<Kierunek> kierunki = new Vector<Kierunek>();
 
    public void dodajKierunek(Kierunek kierunek) {
        if(!kierunki.contains(kierunek)) {
        	kierunki.add(kierunek);
        }
    }
    
    /**
     * Konstruktor
     * 
     * @param id
     * @param nazwa
     * @param adres
     */
	public Wydzial(int id, String nazwa, Adres adres) {
		this.id = id;
		this.nazwa = nazwa;
		this.adres = adres;
	}
	
	public void dodajStudenta(Student s) {
		studenci.add(s);
	}

	public String toString() {
		return "Wydzial [id=" + id + ", nazwa=" + nazwa + ", adres=" + adres
				+ "]";
	}
	
	

}
