import java.util.ArrayList;
import java.util.TreeMap;
import java.util.Vector;


public class Student {
	
	/**
	 * Atrybuty klasy Student
	 */
	int nr_indeksu;
	String imie;
	String nazwisko;
	String email;
	ArrayList<Wydzial> wydzialy = new ArrayList<Wydzial>();
	ArrayList<Integer> oceny = new ArrayList<Integer>();
	double srednia;
   
	/**
	 * Konstruktor klasy Student
	 * 
	 * @param nr_indeksu
	 * @param imie
	 * @param nazwisko
	 * @param email
	 * @param wydzial
	 */
	
	public Student(int nr_indeksu, String imie, String nazwisko, String email,
			Wydzial wydzial) {
		this.nr_indeksu = nr_indeksu;
		this.imie = imie;
		this.nazwisko = nazwisko;
		this.email = email;
		this.wydzialy.add(wydzial);
		dodajStudenta(this);
		wydzial.dodajStudenta(this);
		wydzial.dodajStudentKwalif(this);
	}

	/**
	 * Metody klasy Student
	 */
	
	void dodajWydzial(Wydzial w) {
		wydzialy.add(w);
	}
	
	public void dodajOcene(int ocena) {
		oceny.add(ocena);
	}
	
	public void dodajOcene(int[] oceny) {
		for (int o : oceny) {
			this.oceny.add(o);
		}
	}
	
	public void obliczSrednia() {
		int s = 0;
		int l = oceny.size();
		if (l > 0) {
			for (int o : oceny) {
				s += o;
			}
			this.srednia = ((double) s ) / l;
		}
	}
	
	/**
	 * Metoda klasowa
	 */
	
	static double najlepszaSrednia() {
		double maxSrednia = 0;
		for (Student s : Student.ekstensja) {
			if (s.srednia > maxSrednia) {
				maxSrednia = s.srednia;
			}
		}
		return maxSrednia;
	}
	
	public String toString() {
		return "Student [nr_indeksu=" + nr_indeksu + ", imie=" + imie
				+ ", nazwisko=" + nazwisko + ", email=" + email + ", wydzial="
				+ wydzialy + "]";
	}

	/**
	 * Ekstensja klasy Student
	 */
	public static Vector<Student> ekstensja = new Vector<Student>();
	
	private static void dodajStudenta(Student s) {
		ekstensja.add(s);
	}
	
	private static void usunStudenta(Student s) {
		ekstensja.remove(s);
	}
	
	/**
	 * Wyswietlanie ekstensji klasy Student
	 */
	public static void pokazEkstensje() {
		System.out.println("Ekstensja klasy Student: ");
		for (Student s : ekstensja) {
			System.out.println(s);
		}
	}
	
	
}
