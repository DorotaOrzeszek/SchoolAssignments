import java.util.Date;

/**
 * 
 * @author Dorota Orzeszek
 * Mini-projekt 2: Asocjacje
 *
 */

public class Main {

	public static void main(String[] args) throws Exception {
		
		/**
		 * Tworzę kilka obiektów klas Student, Wydział i Adres.
		 * Na ich przykładzie będę pracować poniżej.
		 */

		Adres a1 = new Adres("Koszykowa", 86, "02-008", "Warszawa");
		Wydzial w1 = new Wydzial(100, "Wydział Informatyki", a1);
		Student s1 = new Student(1001, "Jan", "Kowalski", "j.kowalski@email.com", w1);
		Student s2 = new Student(1002, "Ewa", "Nowak", "e.nowak@email.com", w1);
		Student s3 = new Student(1003, "Anna", "Majewska", "anna.m@email.com", w1);
		
		/**
		 * Asocjacja binarna
		 * 
		 * Asocjacja binarna to zależność między dwoma klasami, np.
		 * 
		 * Student studiuje na Wydziale (asocjacja wiele do wielu). 
		 */
		
		System.out.println("===== ASOCJACJA BINARNA =====");
		System.out.println();
		
		System.out.println("Klasa Student posiada pole wydzialy (ArrayList<Wydzial>) oraz metodę dodajWydzial().");
		System.out.println("Klasa Wydzial posiada pole studenci (ArrayList<Student>) oraz metodę dodajStudenta().");
		System.out.println();
		
		System.out.println("Dla studenta s1:");
		System.out.println(s1.imie + " " + s1.nazwisko);
		for (Wydzial w : s1.wydzialy) {
			System.out.println(w);
		}
		System.out.println();

		System.out.println("Dla wydzialu w1:");
		System.out.println(w1.nazwa);
		for (Student s : w1.studenci) {
			System.out.println(s);
		}

		/**
		 * Asocjacja z atrybutem
		 * 
		 * Asocjacja z atrybutem to asocjacja pomiędzy dwoma klasami, która pozwala przechować dodatkową informację o zależności.
		 * 
		 * Atrybutami asocjacji "Student studiuje na Wydziale" mogą być daty studiowania Od i Do.
		 * 
		 * Aby je zawrzeć, utworzono klasę pomocniczą StudentWydzial o polach dataOd i dataDo.
		 */

		System.out.println();
		System.out.println("===== ASOCJACJA Z ATRYBUTEM =====");
		System.out.println();
		
		StudentWydzial sw1 = new StudentWydzial(s1, w1);
		Date poczatekStudiow = new Date(2005, 10, 1);
		Date koniecStudiow = new Date(2010, 9, 30);
		sw1.setDataOd(poczatekStudiow);
		sw1.setDataDo(koniecStudiow);
		
		System.out.println("Klasa pośrednia StudentWydzial zawiera atrybuty Od i Do");
		System.out.println(sw1);
		
		/**
		 * Asocjacja kwalifikowana
		 * 
		 * Asocjacja kwalifikowana to asocjacja zawierająca dodatkowy atrybut umożliwiający zidentyfikowanie obiektu doecelowego.
		 * 
		 * Kwalifikatorem asocjacji "Student studiuje na Wydziale" mogą być nr_indeksu studenta.
		 * 
		 * Aby go zawrzeć, utworzono słownik studentKwalif oraz metody dodajStudentKwalif i znajdzStudentKwalif w klasie Wydzial.
		 */
		
		System.out.println();
		System.out.println("===== ASOCJACJA KWALIFIKOWANA =====");
		System.out.println();
		
		System.out.println("Studenci wydziału w1 według nr_indeksu");
		for (int i : w1.studentKwalif.keySet()) {
			System.out.println(w1.studentKwalif.get(i));
		}
		
		/**
		 * Kompozycja
		 * 
		 * Kompozycja to forma asocjacji modelująca związek część-całość podobna do agregacji,
		 * ale nadająca dodatkowe ograniczenia, np. część nie może istnieć bez całości ani być współdzielona.
		 * 
		 * Kierunek jest częścią Wydziału.
		 * Gdy usuwamy Wydział, usuwamy też Kierunek.
		 * Usuwając Kierunek nie usuwamy Wydziału.
		 * 
		 * Utworzono wektor kierunki i metodę pomocniczą dodajKierunek w klasie Wydzial oraz klasę Kierunek.
		 */
		
		System.out.println();
		System.out.println("===== KOMPOZYCJA =====");
		System.out.println();

		Kierunek k1 = Kierunek.utworzKierunek(w1, "Informatyka stosowana");
		Kierunek k2 = Kierunek.utworzKierunek(w1, "Informatyka teoretyczna");
				
		System.out.println("Kierunki na wydziale w1:");
		for (Kierunek k: w1.kierunki) {
			System.out.println(k);
		}
		
	}

}
