public class Kierunek {
    public String nazwa;
    private Wydzial wydzial;
 
    private Kierunek(Wydzial wydzial, String nazwa) {
        this.nazwa = nazwa;
        this.wydzial = wydzial;
    }
 
    public static Kierunek utworzKierunek(Wydzial wydzial, String nazwa) throws Exception {
        if(wydzial == null) {
            throw new Exception("Wydział nie istnieje!");
        } 
        Kierunek k = new Kierunek(wydzial, nazwa);
        wydzial.dodajKierunek(k);
        return k;
    }

	@Override
	public String toString() {
		return "Kierunek [nazwa=" + nazwa + ", wydzial=" + wydzial + "]";
	}
    
    
}
