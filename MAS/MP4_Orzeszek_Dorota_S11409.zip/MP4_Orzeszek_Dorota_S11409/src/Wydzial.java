import java.util.ArrayList;
import java.util.TreeMap;
import java.util.Vector;


public class Wydzial {
	
	int id;
	String nazwa;
	ArrayList<Student> studenci = new ArrayList<Student>();

    TreeMap<Integer, Student> studentKwalif = new TreeMap<Integer, Student>();
    
    public void dodajStudentKwalif(Student nowyStudent) {
        if(!studentKwalif.containsKey(nowyStudent.getNrIndeksu())) {
        	studentKwalif.put(nowyStudent.getNrIndeksu(), nowyStudent);
            nowyStudent.dodajWydzial(this);
        }
    }
 
    public Student znajdzStudentKwalif(int nr_indeksu) throws Exception {
        if(!studentKwalif.containsKey(nr_indeksu)) {
            throw new Exception("Nie odnaleziono studenta o nr_indeksu: " + nr_indeksu);
        }
        return studentKwalif.get(nr_indeksu);
    }
	
    /**
     * Konstruktor
     * 
     * @param id
     * @param nazwa
     * @param adres
     */
	public Wydzial(int id, String nazwa) {
		this.id = id;
		this.nazwa = nazwa;
	}
	
	public void dodajStudenta(Student s) {
		studenci.add(s);
	}

	public String toString() {
		return "Wydzial [id=" + id + ", nazwa=" + nazwa + "]";
	}
	
	

}
