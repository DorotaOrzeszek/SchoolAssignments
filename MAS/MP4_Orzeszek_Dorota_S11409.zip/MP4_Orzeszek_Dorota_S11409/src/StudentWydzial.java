import java.util.Date;


public class StudentWydzial {
	
	Student student;
	Wydzial wydzial;
	Date dataOd;
	Date dataDo;
	
	StudentWydzial(Student s, Wydzial w) {
		this.student = s;
		this.wydzial = w;
	}

	public Date getDataOd() {
		return dataOd;
	}

	public void setDataOd(Date dataOd) {
		this.dataOd = dataOd;
	}

	public Date getDataDo() {
		return dataDo;
	}

	public void setDataDo(Date dataDo) {
		this.dataDo = dataDo;
	}

	@Override
	public String toString() {
		return "StudentWydzial [student=" + student + ", wydzial=" + wydzial
				+ ", dataOd=" + dataOd + ", dataDo=" + dataDo + "]";
	}
	
	

}
