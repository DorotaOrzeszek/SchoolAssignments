import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Vector;


public class Student {
	
	String imie;
	String nazwisko;
	Set<Kierunek> kierunki = new HashSet<Kierunek>();
	
	int nrIndeksu = -1;
	static Set<Integer> nryIndeksow = new HashSet<Integer>();
	
	Student(String imie, String nazwisko) {
		this.imie = imie;
		this.nazwisko = nazwisko;
		dodajStudenta(this);
	}
	
	public void setNrIndeksu(int nr) {
		if (!nryIndeksow.contains(nr)) {
			this.nrIndeksu = nr;
			nryIndeksow.add(nr);
		} else {
			System.out.println("Student o takim numerze indeksu już istnieje");
		}
	}

	public int getNrIndeksu() {
		return this.nrIndeksu;
	}

	@Override
	public String toString() {
		return "Student [" + this.imie + " " + this.nazwisko + " (" + this.nrIndeksu + ")]";
	}

	/**
	 * Ekstensja klasy Student
	 */
	public static Vector<Student> ekstensja = new Vector<Student>();
	
	private static void dodajStudenta(Student s) {
		ekstensja.add(s);
	}
	
	private static void usunStudenta(Student s) {
		ekstensja.remove(s);
	}
	
	/**
	 * Wyswietlanie ekstensji klasy Student
	 */
	public static void pokazEkstensje() {
		System.out.println("Ekstensja klasy Student (w ustalonej kolejności): ");
		for (Student s : ekstensja) {
			System.out.println(s);
		}
	}

	private List<String> roleXOR = new LinkedList<String>();
	
	public void dodajRoleXOR(String nazwaRoliXor) {
        roleXOR.add(nazwaRoliXor);
    }
 
    public void dodajPowiazanie_xor(String nazwaRoli, Object obiektDocelowy) {
        if(roleXOR.contains(nazwaRoli)) {
            if(czyIstniejePowiazanie()) {
                System.out.println("Istnieja juz powiazanie w ramach rol objetych ograniczeniem {XOR}!");
            }
        }
        System.out.println(nazwaRoli + " " + obiektDocelowy.getClass());
    }
 
    private boolean czyIstniejePowiazanie() {
        for(String rola : roleXOR) {
            return true;
        }
        return false;
    }
    
    public void setKierunek(Kierunek k) {
    	if (kierunki.size() < 2) {
    		kierunki.add(k);
    	} else {
    		System.out.println("Student studiuje już na max. dopuszczalnej liczbie kierunków");
    	}
    }
	
}
