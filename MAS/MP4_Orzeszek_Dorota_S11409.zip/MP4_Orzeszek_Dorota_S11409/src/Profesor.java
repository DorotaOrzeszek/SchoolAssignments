
public class Profesor {
	
	String imie;
	String nazwisko;
	private double pensja;
	
	Profesor(String imie, String nazwisko) {
		this.imie = imie;
		this.nazwisko = nazwisko;
	}

	public void setPensja(double p) {
		if (p < 1600.0) {
			System.out.println("Wprowadzono wartość poniżej pensji minimalnej");
		}
		this.pensja = p;
	}
	
	public double getPensja() {
		return this.pensja;
	}
}
