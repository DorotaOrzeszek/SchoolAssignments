
public class Kierunek {
	
	String nazwa;
	
	Kierunek(String nazwa) {
		this.nazwa = nazwa;
	}

}
