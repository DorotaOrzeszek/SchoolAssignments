
public class StudentDzienny extends Student {

	StudentDzienny(String imie, String nazwisko) {
		super(imie, nazwisko);
	}

}
