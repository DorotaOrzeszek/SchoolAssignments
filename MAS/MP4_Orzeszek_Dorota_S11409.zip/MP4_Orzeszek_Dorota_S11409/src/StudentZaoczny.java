
public class StudentZaoczny extends Student {

	StudentZaoczny(String imie, String nazwisko) {
		super(imie, nazwisko);
	}

}
