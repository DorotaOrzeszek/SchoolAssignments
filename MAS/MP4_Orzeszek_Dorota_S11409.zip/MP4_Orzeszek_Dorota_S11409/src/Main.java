
/**
 * 
 * @author Dorota Orzeszek
 * Mini-projekt 4: Ograniczenia
 *
 */

public class Main {

	public static void main(String[] args) throws Exception {
		
		/**
		 * Ograniczenie atrybutu
		 */
		
		System.out.println("======= Ograniczenie atrybutu =======");
		
		Profesor prof1 = new Profesor("Jan", "Kwiatkowski");
		prof1.setPensja(1200);
		System.out.println(prof1.getPensja());
		prof1.setPensja(2000);
		System.out.println(prof1.getPensja());

		System.out.println();
		
		/**
		 * Ograniczenie Unique
		 */
		
		System.out.println("======= Ograniczenie Unique =======");
		
		Student s1 = new Student("Anna", "Nowak");
		Student s2 = new Student("Adam", "Kowalski");
		s1.setNrIndeksu(12345);
		System.out.println(s1.getNrIndeksu());
		s2.setNrIndeksu(12345);
		System.out.println(s2.getNrIndeksu());
		
		System.out.println();
		
		/**
		 * Ograniczenie Ordered
		 */
		
		System.out.println("======= Ograniczenie Ordered =======");
		
		Student.pokazEkstensje();
	
		System.out.println();
		
		/**
		 * Ograniczenie Bag
		 */
		
		System.out.println("======= Ograniczenie Bag =======");
		
		System.out.println("Zaimplementowano klasę pośredniczącą StudentWydzial - co rozwiązuje problem implementacji ograniczenia {bag}");
		
		System.out.println();

		/**
		 * Ograniczenie Xor
		 */
		
		System.out.println("======= Ograniczenie Xor =======");
		
		StudentZaoczny sz = new StudentZaoczny("Jan", "Markowski");
		s1.dodajRoleXOR("zaoczny");
		s1.dodajPowiazanie_xor("zaoczny", sz);
		s1.dodajRoleXOR("dzienny");
		
		System.out.println();

		/**
		 * Ograniczenie własne
		 * 
		 * Student może studiować co najwyżej na 2 kierunkach
		 */
		
		System.out.println("======= Ograniczenie własne =======");
		
		Kierunek k1 = new Kierunek("Informatyka");
		Kierunek k2 = new Kierunek("Grafika komputerowa");
		Kierunek k3 = new Kierunek("Elektronika");
		s1.setKierunek(k1);
		s1.setKierunek(k2);
		s1.setKierunek(k3);
		
		System.out.println();

	}

}
