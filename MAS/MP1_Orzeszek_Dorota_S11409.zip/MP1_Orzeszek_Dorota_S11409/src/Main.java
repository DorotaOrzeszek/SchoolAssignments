import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

/**
 * 
 * @author Dorota Orzeszek
 * Mini-projekt 1: Klasy, atrybuty
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		/**
		 * Tworzę kilka obiektów klas Student, Wydział i Adres.
		 * Na ich przykładzie będę pracować poniżej.
		 */

		Adres a1 = new Adres("Koszykowa", 86, "02-008", "Warszawa");
		Adres a2 = new Adres("Koszykowa", 86, 20, "02-008", "Warszawa");

		Wydzial w1 = new Wydzial(1, "Wydzial Informatyki", a1);
		Wydzial w2 = new Wydzial(1, "Wydzial Administracji", a2);

		Student s1 = new Student(1001, "Jan", "Kowalski", "j.kowalski@email.com", w1);
		Student s2 = new Student(1002, "Ewa", "Nowak", "e.nowak@email.com", w1);
		Student s3 = new Student(1003, "Anna", "Majewska", "anna.m@email.com", w1);
				
		/**
		 * Ekstensja
		 * 
		 * Ekstensja klasy to zbiór aktualnie istniejących wszystkich instancji tej klasy.
		 * Wyświetlam ekstensję klasy Student za pomocą metody pokazEkstensje().
		 */
		
		System.out.println("EKSTENSJA KLASY");
		Student.pokazEkstensje();
		System.out.println();
		//
		
		/**
		 *  Ekstensja - trwałość
		 *  
		 *  Trwała ekstensja klasy oznacza, że po ponownym włączeniu systemu obiekty ekstencji
		 *  będą wciąż dostępne.
		 *  Klasa Student zapisuje informacje o swojej ekstensji do pliku, który można potem odczytać.
		 */
		
		System.out.println("TRWAŁOŚĆ EKSTENSJI");
		System.out.println("Ekstensja jest zachowywana w pliku tekstowym na dysku");
	
		PrintWriter writer = null;
		try {
			writer = new PrintWriter("Ekstensja-Student.txt", "UTF-8");
		} catch (FileNotFoundException | UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		writer.println(Student.ekstensja);
		writer.close();
		
		System.out.println();
		
		/** 
		 * Atrybut złożony
		 * 
		 * Atrybut złożony składa się z atrybutów prostych lub innych atrybutów złożonych.
		 * W klasie występuje jako instancja innej klasy a nie bezpośrednia wartość.
		 * Klasa Wydział posiada atrybut złożony -> adres (typ: Adres).	
		 */
		System.out.println("ATRYBUT ZŁOŻONY");
		System.out.println("Atrybut adres jest złożony");
		System.out.println(w1.adres);
		System.out.println();
		
		/** 
		 * Atrybut opcjonalny
		 * 
		 * Atrybut opcjonalny to atrybut, który może nie mieć podanej wartości.
		 * Klasa Adres posiada atrybut opcjonalny -> nr_lokalu (typ: Integer).
		 */
		
		System.out.println("ATRYBUT OPCJONALNY");
		System.out.println("Atrybut nr_lokalu jest opcjonalny");
		System.out.println(a1);
		System.out.println(a2);
		System.out.println();
		
		/**
		 *  Atrybut powtarzalny
		 *  
		 *  Atrybut powtarzalny może mieć wiele wartości.
		 *  Klasa Student posiada atrybut powtarzalny -> wydzialy (typ: ArrayList<Wydzial>)
		 */
		
		System.out.println("ATRYBUT POWTARZALNY");
		System.out.println("Atrybut wydzialy jest opcjonalny");
		s1.dodajWydzial(w2);
		System.out.println(s1.wydzialy);
		System.out.println();
		
		/**
		 *  Atrybut klasowy
		 *  
		 *  Atrybut klasowy ma tę samą wartość dla wszystkich obiektów danej klasy.
		 *  Klasa Adres posiada atrybut klasowy -> kraj (typ: String).
		 */
		
		System.out.println("ATRYBUT KLASOWY");
		System.out.println("Atrybut kraj jest klasowy");
		System.out.println(a1.kraj);
		System.out.println(a2.kraj);
		System.out.println();
		
		/**
		 *  Atrybut pochodny
		 *  
		 *  Klasa Student posiada atrybut pochodny -> srednia (typ: double).
		 *  Można go wyliczyć na podstawie wartości atrybutu oceny (typ: ArrayList<Integer>).
		 */
		
		System.out.println("ATRYBUT POCHODNY");
		System.out.println("Atrybut srednia jest pochodny");
		s2.dodajOcene(5);
		s2.dodajOcene(4);
		s2.obliczSrednia();
		System.out.println(s2.srednia);
		System.out.println();
		
		/**
		 *  Meteoda klasowa
		 *  
		 *  Metoda klasowa ma dostęp do wszystkich obiektów należących do danej klasy.
		 *  Klasa Student posiada metodę klasową najlepszaSrednia()
		 */
		
		s3.dodajOcene(4);
		s3.obliczSrednia();
		
		System.out.println("METODA KLASOWA");
		System.out.println("Metoda najlepszaSrednia() jest metodą klasową");
		double najlepszaSrednia = Student.najlepszaSrednia();
		System.out.println(najlepszaSrednia);
		System.out.println();
		
		/**
		 *  Przesłonięcie
		 *  
		 *  Przesłonięcie metody oznacza stworzenie metody o tej samej sygnaturze w klasie podrzędnej.
		 *  Klasa Adres posiada metodę toString, która przesłania metodę o tej samej nazwie
		 *  automatycznie odziedziczoną po klasie Object.
		 */
		
		System.out.println("PRZESŁANIANIE METOD");
		System.out.println("Metoda toString() w klasie Adres przesłania toString z klasy Object");
		System.out.println(a2);
		System.out.println();
		
		/**
		 *  Przeciążenie
		 *  
		 *  Przeciążenie metody to stworzenie metody o takiej samej nazwie jak metoda przeciążana, 
		 *  ale różnej liczbie i/lub typie parametrów.
		 *  Klasa Student posiada metodę przeciążoną dodajOcene().
		 *  Metoda ta przyjmuje albo pojedyńczą ocenę (int) albo tablicę ocen (int[]).
		 */
		
		System.out.println("PRZECIĄŻĘNIE METODY");
		System.out.println("Metoda dodajOcene() jest przeciążona");
		int[] ocenyS1 = {4, 5, 5};
		s1.dodajOcene(ocenyS1);
		s1.obliczSrednia();
		double najlepszaSrednia2 = Student.najlepszaSrednia();
		System.out.println(najlepszaSrednia2);

	}

}
