
public class Wydzial {
	
	int id;
	String nazwa;
	Adres adres;

	public Wydzial(int id, String nazwa, Adres adres) {
		this.id = id;
		this.nazwa = nazwa;
		this.adres = adres;
	}

	public String toString() {
		return "Wydzial [id=" + id + ", nazwa=" + nazwa + ", adres=" + adres
				+ "]";
	}
	
	

}
