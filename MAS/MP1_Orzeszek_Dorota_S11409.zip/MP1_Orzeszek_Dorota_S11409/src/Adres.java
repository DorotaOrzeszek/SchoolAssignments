
public class Adres {
	
	String ulica;
	int nr_budynku;
	Integer nr_lokalu;
	String kod;
	String miasto;
	static String kraj = "Polska";
	
	public Adres(String ulica, int nr_budynku, Integer nr_lokalu, String kod,
			String miasto) {
		super();
		this.ulica = ulica;
		this.nr_budynku = nr_budynku;
		this.nr_lokalu = nr_lokalu;
		this.kod = kod;
		this.miasto = miasto;
	}
	
	public Adres(String ulica, int nr_budynku, String kod,
			String miasto) {
		super();
		this.ulica = ulica;
		this.nr_budynku = nr_budynku;
		this.kod = kod;
		this.miasto = miasto;
	}
	
	@Override
	public String toString() {
		String a;
		if (this.nr_lokalu != null) {
			a = "Adres:" + "\n" + 
				ulica + " " + nr_budynku + " " + nr_lokalu + "\n" +
				kod + " " + miasto;
		} else {
			a = "Adres:" + "\n" + 
				ulica + " " + nr_budynku + "\n" +
				kod + " " + miasto;
		}
		return a;
	}
	
	

}
